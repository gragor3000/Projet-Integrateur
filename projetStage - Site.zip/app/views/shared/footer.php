<footer class="section section-primary">
	<div class="container">
		<div class="row">
			<div class="col-sm-6">
				<a href="http://www.cegep-lanaudiere.qc.ca/joliette" target="_new" class="text-inverse"><b class="text-uppercase">Cégep Régional <i class="text-lowercase">de</i> Lanaudière</b> <i>à Joliette</i></a>
				<br />
				<a href="http://www.cegep-lanaudiere.qc.ca/joliette/programmes/techniques-de-linformatique" target="_new" class="text-inverse"><small>420.AA | Technique de l'informatique</small></a>
			</div>
			<div class="col-sm-6 text-right">
				<p>Ce site a été conçu dans le cadre du cours de Projet Intégrateur par :
					<br />
					<i>Samuel Baker, Marc Lauzon, Michael Légaré,<br /> Patrick Limoge &amp; Guillaume Payette-Brisson</i>
				</p>
			</div>
		</div>
	</div>
</footer>